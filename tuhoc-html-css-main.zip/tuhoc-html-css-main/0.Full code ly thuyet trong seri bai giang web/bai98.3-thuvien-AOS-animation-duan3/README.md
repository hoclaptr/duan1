# figma-to-html-03
Đây là toàn bộ code dự án số 1 trong seri tự học lập trình HTML CSS tại http://tuhoc.cc  


\*link Figma dự án :


https://www.figma.com/file/3kHcuu3c8fvhnA2q2wUwBM/  


\*\* Link demo kết quả dự án hoàn thiện :
https://galailaptrinh.github.io/figma-to-html-03/  


                        _oo0oo_
                         o8888888o
                        88" . "88
                        (| -_- |)
                        0\  =  /0
                        ___/`---'\___
                    .' \\|     | '.
                    / \\|||  :  ||| \
                    / _||||| -:- |||||- \
                |   | \\\  -  / |   |
                | \_|  ''\---/''  |_/ |
                \  .-\__  '-'  ___/-. /
                ___'. .'  /--.--\  `. .'___
            ."" '<  `.___\_<|>_/___.' >' "".
            | | :  `- \`.;`\ _ /`;.`/ - ` : | |
            \  \ `_.   \_ __\ /__ _/   .-` /  /
        =====`-.____`.___ \_____/___.-`___.-'=====
                        `=---='

 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
   http://Tuhoc.cc Phật phù hộ, không bao giờ BUG
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
